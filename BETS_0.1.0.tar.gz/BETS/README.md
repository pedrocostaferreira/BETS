[![Build Status](https://travis-ci.org/pedrocostaferreira/BETS.svg?branch=master)](https://travis-ci.org/pedrocostaferreira/BETS) [![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/BETS)](https://CRAN.R-project.org/package=BETS)

# BETS - Brazilian Economic Times Series

## Installation

```R
install.packages("BETS") 
```
## Usage

```R
library(BETS)
```
